let Status = function(){
    this.name = null;
    this.init = function(name){
        this.name = name;
        return this;
    }
}